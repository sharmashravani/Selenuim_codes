package pac1;

import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

public class CreateNewCustomerTest {

	@Test()
	public void create() {
		System.out.println("Create Customer and verify the customer is created");
	}
	
	@Test
	public void modify() {
		System.out.println("Create Customer then modify and verify the modified customer");
	}

	@BeforeMethod
	public void login() {
		System.out.println("login to application");
	}

	@AfterMethod
	public void logout() {
		System.out.println("logout of application");
	}

	@BeforeClass
	public void browserlaunch() {
		System.out.println("==Launch empty Browser, Establish a Database Connection==");
	}

	@AfterClass
	public void CloseBrowser() {
		System.out.println("Close the Browser, Disconnect DB");
	}

}