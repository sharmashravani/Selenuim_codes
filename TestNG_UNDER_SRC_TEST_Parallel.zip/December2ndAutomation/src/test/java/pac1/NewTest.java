package pac1;

import org.testng.annotations.Test;

public class NewTest {
	
  @Test
  public void facebookLoginTest() {
	  System.out.println("Running in facebookLoginTest case");
  }
}
