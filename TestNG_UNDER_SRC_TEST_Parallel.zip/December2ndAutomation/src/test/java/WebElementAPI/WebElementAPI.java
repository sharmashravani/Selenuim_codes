package WebElementAPI;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class WebElementAPI {

	static String expectedErrorMsg = "The password that you've entered is incorrect. Forgotten password?";

	public static WebDriver driver;

	public static void main(String[] args) throws Exception {

		// setup the chromedriver file
		System.setProperty("webdriver.chrome.driver", System.getProperty("user.dir") + "\\Driver\\chromedriver.exe");

		// launch the browser
		driver = new ChromeDriver();

		// implicitly wait
		waitForpageToLoad();

		// Open facebook application
		driver.get("https://facebook.com");

		// maximize the window
		driver.manage().window().maximize();

		// get the email edit box
		WebElement email = driver.findElement(By.id("email"));

		// Enter email id
		email.sendKeys("rakeshsinghraks@gmail.com");

		// get the password edit box
		WebElement password = driver.findElement(By.id("pass"));

		// enter password
		password.sendKeys("Hakoonamatata");

		// click on login
		WebElement loginButton = driver.findElement(By.name("login"));

		loginButton.click();

		// capture the error message
		WebElement errorMsgElement = driver.findElement(By.xpath("//div[@class='_9ay7']"));

		// capture the text inside the element
		String actualErrorMsg = errorMsgElement.getText();

		System.out.println(actualErrorMsg);

		// compare the expected error message and actual error message are both the
		// same?

		if (expectedErrorMsg.equalsIgnoreCase(actualErrorMsg)) {
			System.out.println("Error meesage is the same, Test Case == PASS");
		} else {
			System.err.println("Error meesage is not the same, Test Case == FAIL");

		}

		// come back to the login screen
		driver.navigate().back();

		// get the facebook logo webElement
		WebElement facebookLogo = driver.findElement(By.xpath("//img[@alt='Facebook']"));

		boolean status = facebookLogo.isDisplayed();
		System.out.println("Whether Facebook logo is displayed == " + status);

		// click on Create new Account button
		driver.findElement(By.xpath("(//a[normalize-space()='Create new account'])")).click();

		// java wait statement
		Thread.sleep(3000);
		
		//Explicit wait

		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(20));

		wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//input[@type='radio' and @value = '2']")));

		// check if the MALE radio button is selected or not.

		WebElement maleRadioButton = driver.findElement(By.xpath("//input[@type='radio' and @value = '2']"));

		maleRadioButton.click();

		boolean status2 = maleRadioButton.isSelected();

		System.out.println("Is Male option already selected == " + status2);

		// implicitly wait
		// driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(20));

		// check if the Signup button is enabled or not
		WebElement signpButton = driver.findElement(By.name("websubmit"));

		boolean status3 = signpButton.isEnabled();

		System.out.println("Is Signup button enabled == " + status3);

		// how to get any css value for the webElement
		String cssValue = signpButton.getCssValue("font-family");

		System.out.println("Css Value for Signup button == " + cssValue);

		// how to get the attribute value from the WebElement
		String attribute = signpButton.getAttribute("type");

		System.out.println("Signup Attribute 'Type' has a value as == " + attribute);

		// how to get the tagname of the webelement
		String tagname = signpButton.getTagName();

		System.out.println("tagname of the Signup button is == " + tagname);

	}

	public static void waitForpageToLoad() {
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(20));
	}
	
	
	public static void waitForElement(String xpath) {
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(20));

		wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(xpath)));

	}

}
