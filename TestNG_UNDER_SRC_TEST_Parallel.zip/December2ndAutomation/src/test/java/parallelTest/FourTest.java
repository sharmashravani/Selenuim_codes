package parallelTest;

import java.time.Duration;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;

public class FourTest {

	static Alert alert;

	@Test(groups = { "Regression Test" })
	public void FrameHandlingTest() {

		// Set the properties
		System.setProperty("webdriver.chrome.driver", "..\\Novermber13thAutomation\\Drivers\\chromedriver.exe");

		// launch the light browser
		WebDriver driver = new ChromeDriver();

		// Implicitly wait
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(20));

		// Hit the application url
		driver.get("http://the-internet.herokuapp.com/iframe");

		// maximize the window
		driver.manage().window().maximize();

		// switch to iframe to perform operation
		driver.switchTo().frame("mce_0_ifr");

		WebElement body = driver.findElement(By.id("tinymce"));

		body.clear();
		body.sendKeys("Rakesh Yogi");

		// switch to parent Html document or default content
		driver.switchTo().defaultContent();

		// capture the text from the header
		WebElement headerText = driver.findElement(By.tagName("h3"));

		System.out.println("headerText = " + headerText.getText());

		driver.quit();
	}

	@Test(groups = { "Smoke Test" })
	public void AlertTest() throws Exception {

		// Set the properties
		System.setProperty("webdriver.chrome.driver", "..\\Novermber13thAutomation\\Drivers\\chromedriver.exe");

		// launch the light browser
		WebDriver driver = new ChromeDriver();

		// Implicitly wait
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(20));

		// Hit the application url
		driver.get("http://the-internet.herokuapp.com/javascript_alerts");

		// maximize the window
		driver.manage().window().maximize();

		// capture Btn "Click for js Confirm"
		WebElement ClickForJSConfirm = driver.findElement(By.xpath("//button[text() = 'Click for JS Confirm']"));
		ClickForJSConfirm.click();

		// shift focus of selenium from HTML to javaScript Alerts
		alert = driver.switchTo().alert();

		Thread.sleep(5000);

		// Capture the message from the alert
		String currentAlertMessage = alert.getText();
		System.out.println("currentAlertMessage = " + currentAlertMessage);

		// accept the alert
		// alert.accept();
		alert.dismiss();

		WebElement result = driver.findElement(By.id("result"));

		System.out.println("result = " + result.getText());

		// capture btn "click on JS Prompt"
		driver.findElement(By.xpath("//button[@onclick='jsPrompt()']")).click();

		// shift focus of selenium from HTML to javaScript Alerts
		alert = driver.switchTo().alert();

		alert.sendKeys("Hakoonamatata");
		alert.accept();

		System.out.println("result = " + result.getText());

		driver.quit();

	}
}
