package WindowHandling;

import java.time.Duration;
import java.util.Iterator;
import java.util.Set;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class WindowSwitching {

	public static void main(String[] args) {

		// Setup the driver path
		System.setProperty("webdriver.chrome.driver", "..\\December2ndAutomation\\Drivers\\chromedriver.exe");

		// How to invoke a browser
		WebDriver driver = new ChromeDriver();

		// implcitly wait statement -
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(20));

		// Hit the url of the application
		driver.get("https://irctc.co.in");

		// maximize the screen - Maximizes the current window if it is not already
		// maximized
		driver.manage().window().maximize(); // method chaining

		// capture the flights webElement and cick on it
		WebElement flights = driver.findElement(By.xpath("//a[contains(@aria-label,'Menu Flight')]"));

		// click on flights
		flights.click();

		// get the current window id
		String parentWind = driver.getWindowHandle();

		System.out.println("Parent Window Id = " + parentWind);

		// get the window title
		String parentTitle = driver.getTitle();
		System.out.println("parentTitle = " + parentTitle);

		// get the window Ids of all the windows which are opened by selenium

		Set<String> set = driver.getWindowHandles();

		System.out.println("set = " + set);

		// Iterator methods we will use to retrieve values from set object

		Iterator<String> it = set.iterator();
		String parentWindowId = it.next();
		System.out.println("parentWindowId = " + parentWindowId);
		boolean status = it.hasNext();
		System.out.println("Do we have another windowId = " + status);

		String flightsWindowId = it.next();
		System.out.println("flightsWindowId = " + flightsWindowId);

		// Shift focus to Flights window Id
		driver.switchTo().window(flightsWindowId);

		// identify that user is on flights window
		String currenturl = driver.getCurrentUrl();
		System.out.println("currenturl = " + currenturl);

		if (currenturl.contains("air")) {
			System.out.println("User is on Flights window");
			driver.close();
		} else {
			System.out.println("User is still not on flights window");
		}

		// get the lost focus of selenium on parent window
		driver.switchTo().window(parentWindowId);

		String parentUrl = driver.getCurrentUrl();
		System.out.println("parentUrl = " + parentUrl);
	}

}
