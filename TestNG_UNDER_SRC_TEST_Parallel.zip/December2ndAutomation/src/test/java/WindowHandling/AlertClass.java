package WindowHandling;

import java.time.Duration;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class AlertClass {

	static Alert alert;
	static String resultInText;

	public static void main(String[] args) {
		// Setup the driver path
		System.setProperty("webdriver.chrome.driver", "..\\December2ndAutomation\\Drivers\\chromedriver.exe");

		// How to invoke a browser
		WebDriver driver = new ChromeDriver();

		// implcitly wait statement -
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(20));

		// Hit the url of the application
		driver.get("http://the-internet.herokuapp.com/javascript_alerts");

		// maximize the screen - Maximizes the current window if it is not already
		// maximized
		driver.manage().window().maximize(); // method chaining

		// capture the button
		WebElement jsConfirmBtn = driver.findElement(By.xpath("//button[@onclick='jsConfirm()']"));

		jsConfirmBtn.click();

		// Shift the focus to Alert
		alert = driver.switchTo().alert();

		// Get the text from the alert -
		String warningMsg = alert.getText();
		System.out.println("warningMsg = " + warningMsg);

		// alert.accept();
		alert.dismiss();
		// capture the result -

		WebElement result = driver.findElement(By.id("result"));

		String resultInText = result.getText();
		System.out.println("resultInText = " + resultInText);

		///////////////////////////////////////////////////////////

		driver.findElement(By.xpath("//button[@onclick='jsPrompt()']")).click();

		// Shift the focus to Alert
		alert = driver.switchTo().alert();

		alert.sendKeys("rakeshsinghraks");
		alert.accept();

		resultInText = result.getText();
		System.out.println("resultInText = " + resultInText);
	}

}
