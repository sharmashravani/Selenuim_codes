package WebDriverAPI;

import java.time.Duration;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class BrowserControl {

	public static void main(String[] args) throws Exception {

		// Setup the driver path
		System.setProperty("webdriver.chrome.driver", "..\\December2ndAutomation\\Drivers\\chromedriver.exe");

		// How to invoke a browser
		WebDriver driver = new ChromeDriver();

		// implcitly wait statement -
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(20));

		// Hit the url of the application
		driver.get("https://facebook.com");

		// maximize the screen - Maximizes the current window if it is not already
		// maximized
		driver.manage().window().maximize(); // method chaining

		// java Wait Statement -
		Thread.sleep(5000);
		System.out.println("Thread.sleep(5000) has been executed");

		// try to navigate to another application
		driver.navigate().to("https://amazon.in");

		// validate that user is on Amazon page
		String currentUrl = driver.getCurrentUrl();

		if (currentUrl.contains("amazon")) {
			System.out.println("User is on Amazon web page");
		} else {
			System.out.println("User is not on Amazon web page");
		}

		// since I am on Amazon page - navigate back
		driver.navigate().back();

		// validate that the user is on Facebook page
		String currentTitle = driver.getTitle();

		if (currentTitle.equalsIgnoreCase("Facebook – log in or sign up")) {
			System.out.println("User is on facebook page");
		} else {
			System.out.println("User is not on facebook page");
		}

		// write something in email edit box
		WebElement email = driver.findElement(By.id("email"));
		
		//Explicitly wait statement - 
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(20));
		
		wait.until(ExpectedConditions.elementToBeClickable(email));
		
		email.clear();
		email.click();
		email.sendKeys("rakeshsinghraks@gmail.com");

		// String pageSource = driver.getPageSource();
		// System.out.println("pageSource = " + pageSource);

		// close the entire browser
		driver.quit();

	}

}
