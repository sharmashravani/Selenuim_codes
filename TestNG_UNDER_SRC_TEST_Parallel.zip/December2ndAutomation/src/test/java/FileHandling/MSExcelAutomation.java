package FileHandling;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRichTextString;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class MSExcelAutomation {

	public static void main(String[] args) throws Exception {

		//readDataFromExcel();
		setExcelData();
	}

	public static void readDataFromExcel() throws Exception {

		File filepath = new File("..\\December2ndAutomation\\TestData\\TestData.xlsx");

		FileInputStream fis = new FileInputStream(filepath);

		// Open workbook in a read mode
		XSSFWorkbook workbook = new XSSFWorkbook(fis);

		// get the control of the sheet
		XSSFSheet sheet = workbook.getSheet("Sheet1");

		// get control of the row
		XSSFRow row = sheet.getRow(1);

		// get the data
		String url = row.getCell(2).getStringCellValue();
		String username = row.getCell(3).getStringCellValue();
		String password = row.getCell(4).getStringCellValue();

		System.out.println("url = " + url);
		System.out.println("username = " + username);
		System.out.println("password = " + password);

	}

	public static void setExcelData() throws Exception {
		File filepath = new File("..\\December2ndAutomation\\TestData\\TestData.xlsx");

		FileInputStream fis = new FileInputStream(filepath);

		// Open workbook in a read mode
		XSSFWorkbook workbook = new XSSFWorkbook(fis);

		// get the control of the sheet
		XSSFSheet sheet = workbook.getSheet("Sheet1");

		// get control of the row
		XSSFRow row = sheet.getRow(1);

		XSSFCell cell = row.createCell(5);

		FileOutputStream fos = new FileOutputStream(filepath);

		cell.setCellValue("ORDER10110");

		workbook.write(fos);

		workbook.close();

	}
}
