package TestScript;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;
import org.testng.annotations.Test;

import Generic.Drivers;
import pageObjects.Login;

public class LoginTest {

	public static WebDriver driver;

	@Test
	public void positiveScenarioLoginTest() throws Exception {
		
		driver = Drivers.getBrowser();

		Login login = PageFactory.initElements(driver, Login.class);

		login.login(driver);
	}
}
