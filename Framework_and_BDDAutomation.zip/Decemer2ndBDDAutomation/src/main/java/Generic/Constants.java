package Generic;

public interface Constants {
	
	String browser = "ChRoMe";
	
	String driverpath = "..\\Decemer2ndBDDAutomation\\Drivers\\";
	
	int globalWait = 20;
	
	String TestDataFilePath = "..\\Decemer2ndBDDAutomation\\TestData\\TestData.xlsx";

	String appUrl = "https://opensource-demo.orangehrmlive.com/web/index.php/auth/login";

}
