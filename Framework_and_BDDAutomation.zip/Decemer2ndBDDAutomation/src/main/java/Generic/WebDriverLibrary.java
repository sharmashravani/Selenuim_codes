package Generic;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class WebDriverLibrary {

	public static WebDriver driver = Drivers.driver;
	public static WebDriverLibrary webdriverLibrary = new WebDriverLibrary();
	public static Actions act = new Actions(driver);

	/**
	 * This is implicit webDriver wait statement and this method is used for page to
	 * load, it checks that the page is loaded in every 500ms
	 */
	public static void waitForPageToLoad() {
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(Constants.globalWait));
	}

	/**
	 * This is explicit webDriver wait statement and it is used for wait for the
	 * element to become clickable, it checks in every 500ms whether the element is
	 * clickable or not.
	 * 
	 * Once the it is, it release the control to the next line, to perform the
	 * action.
	 * 
	 * @param by
	 */
	public static void waitForElementToBeClickable(By by) {

		// Explicitly wait statement -
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(Constants.globalWait));

		wait.until(ExpectedConditions.elementToBeClickable(by));
	}

	/**
	 * This method is used to switch window controls
	 * 
	 * @param driver
	 * @param windowId
	 */
	public void switchWindowTo(WebDriver driver, String windowId) {
		driver.switchTo().window(windowId);
	}

	/**
	 * User need to provide one data to use frame switching method
	 * 
	 * @param id_or_name
	 */
	public void switchingToFrame(String id_or_name) {

		driver.switchTo().frame(id_or_name);

	}

	/**
	 * With the help of this method you will be able to wait for the webElement to
	 * be located by the xpath which comes from the user itself
	 * 
	 * @param xpath
	 */
	public static void waitForElementPresent(WebDriver driver, By locator) {

		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(Constants.globalWait));

		wait.until(ExpectedConditions.presenceOfElementLocated(locator));
	}

	/**
	 * This webDriver wait statement waits for the element to be visible using the
	 * xpath.
	 * 
	 * @param xpath
	 */
	public void waitForXpathPresent(WebDriver driver, By locator) {

		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(Constants.globalWait));

		wait.until(ExpectedConditions.visibilityOfElementLocated(locator));
	}

	public static void verifytext(By locator, String expectedValue) {

		WebDriverLibrary.waitForPageToLoad();
		// boolean flag = false; // buld concept
		WebElement element = driver.findElement(locator);
		String actualtext = element.getText();
		if (expectedValue.equalsIgnoreCase(actualtext)) {
			System.out.println("The expected texts is matching with the Actual Text");
		} else {
			System.out.println("Actual value is not matching with expected Value");
		}
	}

	public static void switchToAlert(WebDriver driver) {
		driver.switchTo().alert();
	}

	public static void dragAndDrop(WebDriver driver, String fromXpath, String toXpath) {
		WebElement from = driver.findElement(By.xpath(fromXpath));
		WebElement To = driver.findElement(By.xpath(toXpath));
		// Using Actions class for Drag and Drop
		act = new Actions(driver);
		act.dragAndDrop(from, To).build().perform();
		System.out.println("Drag And Drop Operation has been performed successfully");

	}

	public static void maximize(WebDriver driver) {
		driver.manage().window().maximize();
	}
}
