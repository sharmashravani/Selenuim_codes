package Generic;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class MsExcelAutomation {

	public static String readDataFromExcel(String sheetName, int rowNum, int cellNum) throws Exception {

		File filepath = new File(Constants.TestDataFilePath);

		FileInputStream fis = new FileInputStream(filepath);

		// Open workbook in a read mode
		XSSFWorkbook workbook = new XSSFWorkbook(fis);

		// get the control of the sheet
		XSSFSheet sheet = workbook.getSheet(sheetName);

		// get control of the row
		XSSFRow row = sheet.getRow(rowNum);

		// get the data
		String data = row.getCell(cellNum).getStringCellValue();

		System.out.println("Data From Excel = " + data);

		return data;
	}

	public static void setExcelData(String sheetName, int rowNum, int cellNum, String valueToPaste) throws Exception {
		File filepath = new File(Constants.TestDataFilePath);

		FileInputStream fis = new FileInputStream(filepath);

		// Open workbook in a read mode
		XSSFWorkbook workbook = new XSSFWorkbook(fis);

		// get the control of the sheet
		XSSFSheet sheet = workbook.getSheet(sheetName);

		// get control of the row
		XSSFRow row = sheet.getRow(rowNum);

		XSSFCell cell = row.createCell(cellNum);

		FileOutputStream fos = new FileOutputStream(filepath);

		cell.setCellValue(valueToPaste);

		workbook.write(fos);

		workbook.close();

	}
}
