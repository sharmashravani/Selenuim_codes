package Generic;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.safari.SafariDriver;

public class Drivers {

	public static WebDriver driver;

	public static WebDriver getBrowser() {

		if (Constants.browser.equalsIgnoreCase("chrome")) {
			// Setup the driver path
			System.setProperty("webdriver.chrome.driver", Constants.driverpath + "chromedriver.exe");

			// How to invoke a browser
			driver = new ChromeDriver();

			// implcitly wait statement -
			WebDriverLibrary.waitForPageToLoad();

		} else if (Constants.browser.equalsIgnoreCase("firefox")) {

			// Setup the driver path
			System.setProperty("webdriver.firefox.driver", Constants.driverpath + "geckodriver.exe");

			// How to invoke a browser
			driver = new FirefoxDriver();

			// implcitly wait statement -
			WebDriverLibrary.waitForPageToLoad();

		} else if (Constants.browser.equalsIgnoreCase("safari")) {

			// Setup the driver path
			System.setProperty("webdriver.safari.driver", Constants.driverpath + "safaridriver.exe");

			// How to invoke a browser
			driver = new SafariDriver();

			// implcitly wait statement -
			WebDriverLibrary.waitForPageToLoad();
		}

		return driver;

	}

}
