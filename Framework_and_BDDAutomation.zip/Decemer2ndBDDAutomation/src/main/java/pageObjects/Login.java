package pageObjects;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import Generic.Constants;
import Generic.Drivers;
import Generic.MsExcelAutomation;
import Generic.WebDriverLibrary;

public class Login {

	@FindBy(xpath = "//input[@placeholder='Username']")
	private WebElement userName;

	@FindBy(name = "password")
	private WebElement passWord;

	@FindBy(xpath = "//button[@type='submit']")
	private WebElement loginBtn;

	public void login(WebDriver driver) throws Exception {

		// Hit the url
		driver.get(Constants.appUrl);

		// maximize
		WebDriverLibrary.maximize(driver);
		
		// Implicitly wait
		WebDriverLibrary.waitForPageToLoad();

		userName.sendKeys(MsExcelAutomation.readDataFromExcel("Sheet1", 1, 3));

		passWord.sendKeys(MsExcelAutomation.readDataFromExcel("Sheet1", 1, 4));

		loginBtn.click();

	}
}
