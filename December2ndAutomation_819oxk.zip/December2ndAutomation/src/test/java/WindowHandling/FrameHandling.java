package WindowHandling;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class FrameHandling {

	public static void main(String[] args) {
		// Setup the driver path
		System.setProperty("webdriver.chrome.driver", "..\\December2ndAutomation\\Drivers\\chromedriver.exe");

		// How to invoke a browser
		WebDriver driver = new ChromeDriver();

		// implcitly wait statement -
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(20));

		// Hit the url of the application
		driver.get("https://the-internet.herokuapp.com/iframe");

		// maximize the screen - Maximizes the current window if it is not already
		// maximized
		driver.manage().window().maximize(); // method chaining

		// Shift focus to the iframe
		driver.switchTo().frame("mce_0_ifr");

		// write your name in editor box
		WebElement editor = driver.findElement(By.tagName("p"));
		editor.clear();

		editor.sendKeys("Rakesh Kumar Singh");
	}

}
