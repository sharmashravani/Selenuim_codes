package FirstClass;

public class PrintStatements {

	public static void main(String[] args) {

		System.out.print("Good");
		System.out.print("Morning");
		System.out.print("Welcome");

		System.out.println("===========================");

		System.out.print("Good" + "\n");
		System.out.print("Morning" + "\n");
		System.out.print("Welcome" + "\n");

		System.out.println("Good");
		System.out.println("Morning");
		System.out.println("Welcome");

		System.out.println("================================");

		// In between 2 numbers if + sign is there, then arithmetic operation will
		// happen
		System.out.println(10 + 2); // 12

		// in between String and a number + sign acts as concatenating (joining)
		// operator
		System.out.println("10" + 2); // 102 
		System.out.println("10" + "10"); // 1010
		System.out.println("10 + 10"); // 10 + 10

		// ASCII value
		// In between a character and a number if + sign is there then Arithmetic
		// Operation will happen because the character will change to its ASCII value
		System.out.println('a' + 0);

		System.out.println("Rakesh" + " Singh");

		// Operation starts from left --> Right and 2 inputs at a time
		System.out.println("My age is " + 10 + 5 + 10 + 5);
		// "My age is 105105"

		// BODMAS rule
		// According to BODMAS rule, the brackets have to be solved first followed by
		// powers or roots (i.e. of), then Division, Multiplication, Addition, and at
		// the end Subtraction

		System.out.println("My age is " + (10 + 5 + 12));

	}
}
