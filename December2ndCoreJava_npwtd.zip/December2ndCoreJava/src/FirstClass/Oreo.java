package FirstClass;

public class Oreo {

	//Variables - state and properties
	//Variables - class knows something
	static String name = "Oreo";
	static int age = 2;

	public static void main(String[] args) {
		
		//method calls
		play();
		
		run();
	}

	// Methods - Behavior / Actions
	// With the methods - class does something
	public static void play() {
		System.out.println("Running in play()");
	}

	public static void eat() {
		System.out.println("Running in eat()");
	}

	public static void bark() {
		System.out.println("Running in bark()");
	}

	public static void run() {
		System.out.println("Running in run()");
	}

}
