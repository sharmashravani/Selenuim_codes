package Methods;

public class CallingAndExecutionOrder {

	public static void main(String[] args) {

		//method call
		m3();
	}
	
	public static void m1() {
		System.out.println("Running in m1()");
	}

	public static void m2() {
		System.out.println("Running in m2()");
		m1();
	}

	public static void m3() {
		System.out.println("Running in m3()");
		m2();
	}


}
