package Methods;

/**
 * When multiple methods exists with the same name but differs in the argument
 * that to in a same class then it is known as Method Overloading.
 * 
 * Attachment of method calls with the respective method bodies, in the .class
 * file after the compilation, is known as EARLY BINDING / STATIC POLYMORPHISM.
 * 
 * @author Rakesh
 *
 */

public class MethodOverloading {

	public static void main(String[] args) {

		// method calls
		click();
		click(2);
		click("Mobiles");

	}

	public static void click() {
		System.out.println("Running in click() zero argumented");
	}

	public static void click(String name) {
		System.out.println("Name = " + name);
		System.out.println("Running in click(String) String argumented");
	}

	public static void click(int numberedElement) {
		System.out.println("int numberedElement = " + numberedElement);
		System.out.println("Running in click(int) int argumented");

	}
}
