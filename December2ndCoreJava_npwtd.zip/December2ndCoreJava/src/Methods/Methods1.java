package Methods;

import Variables.GlobalVariables;

public class Methods1 {

	public static void main(String[] args) {

		//Method Calls
		m1();
		
		// ClassName.MethodName();
		Methods1.m2();
		
		m3();
		
		//calling m4() from another class named GloablVariables
		GlobalVariables.m4();
	}

	public static void m1() {
		System.out.println("Running in m1()");
	}

	public static void m2() {
		System.out.println("Running in m2()");
	}

	public static void m3() {
		System.out.println("Running in m3()");
	}

}
