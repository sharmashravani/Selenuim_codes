package Methods;

public class Methods2 {

	public static void main(String[] args) {

		Methods2 obj = new Methods2();

		obj.m1();
		obj.m2();
		obj.m3();
		
	}

	public void m1() {
		System.out.println("Running in m1()");
	}

	public void m2() {
		System.out.println("Running in m2()");
	}

	public void m3() {
		System.out.println("Running in m3()");
	}
	
	//default constructor
	public Methods2() {
		
	}

}
