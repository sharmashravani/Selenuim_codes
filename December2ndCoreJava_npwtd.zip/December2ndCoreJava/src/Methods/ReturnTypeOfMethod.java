package Methods;

/*
 * Every method will have a "return" statement to the end of a method.
 * 
 * Between return and a semicolon(;) if no data is available then it is called
 * as default return statement.
 * 
 * For default return statement void is a return type
 * 
 * If the user is not defining a return statement in a method, compiler will
 * auto-generate a return statement and it is called as default return statement, it will be there in the .class file
 * 
 * If there is a data or a value available between "return" and a semicolon(;)
 * depending on the type of value return type of a method will change.
 * 
 */

public class ReturnTypeOfMethod {

	public static void main(String[] args) {

		String catchingData = getdataFromExcel("sheetname", 1, 1);
		System.out.println("catchingData = " + catchingData);

		String whatIsComing = name();
		System.out.println("whatIsComing = " + whatIsComing);

	}

	// return statement auto generate --> compiler
	public static String getdataFromExcel(String sheetName, int rowNum, int cellNum) {

		// logic to read the data from excel

		String data = "Hakoonamatata";

		return data;
	}

	public static String name() {

		return "Sayali";
	}

}
