package Methods;

public class ArgumentedMethods {

	public static void main(String[] args) {

		// method call
		getMyAge(28);
		whatsYourName("Rakesh Yogi");

		emcSquare(10, 20, 30);

	}

	public static void getMyAge(int age) {

		System.out.println("My Age is = " + age);
	}

	public static void whatsYourName(String name) {
		System.out.println("My name is = " + name);
	}

	public static void emcSquare(int e, int m, int c) {

		int result = e + m + c;

		System.out.println("E = " + e);
		System.out.println("M = " + m);
		System.out.println("C = " + c);
		System.out.println("result = " + result);

	}

}
