package Methods;

/*
 * Constructor is nothing but a special type of a method which doesn't have any return type.
 * 
 * It always holds the className.
 * 
 * It doesn't have any modifier - static keyword.
 * 
 * When an object is created for a class, automatically constructor will get called and executed.
 * 
 * Constructor will have access specifier - >> public, private...
 * 
 * Constructor is utilized to initialize the object
 * 
 * Since there is no issue to have multiple constructors inside a class provided 
 * they are differing in the argument, this is known as Constructor Overloading
 * 
 */

public class Constructor {

	public static void main(String[] args) {

		// How to call constructors
		Constructor obj1 = new Constructor(); // --> call to constructor
		Constructor obj2 = new Constructor(20); // --> call to constructor
	}

	// Constructor
	public Constructor() {

		System.out.println("God helps those who help themselves");
	}

	public Constructor(int a) {

		System.out.println("a = " + a);
	}

}
