package AbstractionAndInterface;

public class Builder extends Architect{

	public static void main(String[] args) {

		Builder b = new Builder();
		b.m2();
	}

	public void m2() {
		System.out.println("implemented in Bplus class");
	}
	
	

}
