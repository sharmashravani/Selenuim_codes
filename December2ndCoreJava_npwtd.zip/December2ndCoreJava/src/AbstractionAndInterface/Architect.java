package AbstractionAndInterface;

/**
 * Abstraction guarantees 0% to 100% abstraction
 * 
 * Advantages - 
 * 
 * To achieve code standardization abstraction is required.
 * 
 * To achieve specification we use abstraction
 * 
 * Disadvantage - 
 * 
 * Using abstract class we can not guarantee 100% abstraction.
 * 
 * @author Rakesh
 *
 */

public abstract class Architect {

	public static void main(String[] args) {

		// Cannot instantiate the type Aplus, because it is incomplete class
		// Architect a = new Architect();

	}

	// fully complete method / concrete method
	public void m1() {
		System.out.println("Running in m1()");
	}

	// incomplete method // abstract method
	public abstract  void m2();

	public static void m3() {
		System.out.println("Running in m3() of Architect class");
	}
	
	public void m4() {
		System.out.println("Running in m4() of Architect class");
	}

}
