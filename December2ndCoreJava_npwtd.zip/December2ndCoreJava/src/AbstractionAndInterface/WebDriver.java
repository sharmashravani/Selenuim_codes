package AbstractionAndInterface;

/**
 * Interface is nothing but an abstract class which guarantees 100% abstraction.
 * 
 * interface starts with keywords called interface followed by interface name.
 * 
 * All methods which are available in interface are abstract and public methods.
 * 
 * we can not create an object for interface.
 * 
 * Between a class and interface "implements" will be there to establish IS-A relationship.
 * 
 * B/w class and class ==> extends
 * 
 * B/w interface and Interface ==> extends
 * 
 * The one which exists on LHS of implements is always a sub class.
 * 
 * the one which stays on Right hand side is always a super class.
 * 
 * 
 * 
 * @author Rakesh
 *
 */


public interface WebDriver {
	
	void get(String url);
	
	abstract void getCurrentUrl();
	
	public abstract void close();
}
