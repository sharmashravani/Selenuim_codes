package Variables;

/**
 * Local Variable care temporary variables, defined in a body of a method
 * 
 * Scope of local variables are not in any other methods because are created for
 * temporary purpose in a method.
 * 
 * static keyword / modifier is not applicable for local variables
 * 
 * Instead of initialization, if I directly use local variable only with
 * declaration then it will give error.. because JVM is not bothered about the
 * temporary variables to provide them the default value, it only provides
 * default value to the global variable. Hence it is recommended to do
 * initialization at-least for the declared variable
 * 
 * 
 * @author Rakesh
 *
 */
public class LocalVariables {

	public static void main(String[] args) {

		// local variable - Temporary Variables
		int x; // declaration
		x = 300;
		System.out.println(x);

		// Declaration and Initialization in single line
		int y = 400;
		System.out.println(y);

		// Illegal modifier "static" for parameter d; only final is permitted
		// static double d =39.831;

		int z; // declaration
		z=0;
		// Instead of initialization, if I directly use local variable then it will give
		// error.
		// stating - The local variable z may not have been initialized
		 System.out.println(z);

	}

	public static void m1() {
		// x cannot be resolved to a variable
		// System.out.println(x);
	}

}
