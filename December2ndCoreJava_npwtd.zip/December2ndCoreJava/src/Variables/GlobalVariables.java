package Variables;

/**
 * For Global Variables - JVM assigns default values based on data type
 * 
 * Global variables are of 2 types - static Variable and non-static | instance
 * Variable | data member
 * 
 * We can do utilization of a global variable even if initialization is not done
 * by the programmer.
 * 
 *
 * Non-Static Variable -
 *
 */

public class GlobalVariables {

	static int x; // declaration

	static int y; // declaration

	double d = 350.33;

	public static void main(String[] args) {

		GlobalVariables obj = new GlobalVariables();
		System.out.println("value of  non-static variable d from object = " + obj.d);

		obj.m5();
		
		System.out.println(y);
		y = 300; // initialization in another line for global variable
		System.out.println("==============");
		m1();
		System.out.println("==============");
		m2();
		System.out.println("==============");
		m3();
		System.out.println("==============");
		m4();

		// To access non-static variable we need to create object
		// ClassName referenceVariable = new ClassName();

	}

	public static void m1() {

		System.out.println("Running in m1()");
		System.out.println(y);
	}

	public static void m2() {
		System.out.println("Running in m2()");
		System.out.println(y);
	}

	public static void m3() {
		System.out.println("Running in m3()");
		System.out.println(y);
	}

	public static void m4() {
		System.out.println("Running in m4()");
		System.out.println(y);

	}

	public void m5() {
		System.out.println("Running in non-static m5()");
	}
}
