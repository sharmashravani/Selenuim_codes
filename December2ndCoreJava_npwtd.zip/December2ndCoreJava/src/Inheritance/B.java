package Inheritance;

public class B extends A {

	public static void main(String[] args) {

		B obj = new B();

		System.out.println("========= Super class content ========");
		System.out.println("Value of x = " + obj.x);
		obj.show();
		obj.display();

		System.out.println("========= Sub class content ========");

		obj.demo();
		
		System.out.println("========= HAS-A relationship ========");

		
		// HAS-A relationship
		A ref = new A();
		ref.show();
		ref.display();

	}

	public void demo() {
		System.out.println("Running in demo()");
	}

}
