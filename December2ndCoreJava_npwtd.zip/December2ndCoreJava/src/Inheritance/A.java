package Inheritance;

public class A {

	int x = 350;

	public static void main(String[] args) {

		A ref = new A();

		System.out.println("Value of X = " + ref.x);

		ref.show();
		ref.display();
	}

	public void show() {
		System.out.println("Running in show()");
	}

	public void display() {
		System.out.println("Running in display()");
	}

}
