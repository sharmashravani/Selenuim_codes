package OverRiding;

public class Son extends Father{
	
	int x =400;

	public static void main(String[] args) {

		
		Son s = new Son();
		s.job();
		System.out.println("value of x from Father class is = "+s.x);
		
	}
	
	public void job() {
		System.out.println("Private job");
	}


}
