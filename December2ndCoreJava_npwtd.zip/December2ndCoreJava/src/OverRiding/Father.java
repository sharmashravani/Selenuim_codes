package OverRiding;

public class Father {
	
	int x =350;

	public static void main(String[] args) {

		Father f = new Father();
		f.job();
	}

	public void job() {
		System.out.println("Government job");
	}

}
