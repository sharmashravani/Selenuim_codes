package TypeCasting;

public class ChromeDriver extends RemoteWebDriver {

	public static void main(String[] args) {

	}

	public void extraImplementation1F() {

	}

	public void extraImplementation2() {

	}

	public void extraImplementation3() {

	}

	public void extraImplementation4() {

	}

	public void extraImplementation5() {

	}
}
