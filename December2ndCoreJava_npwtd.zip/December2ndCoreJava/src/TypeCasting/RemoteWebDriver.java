package TypeCasting;

public class RemoteWebDriver implements WebDriver {

	public static void main(String[] args) {

		RemoteWebDriver obj = new RemoteWebDriver();

		obj.get("https://facebook.com");
		obj.getCurrentUrl();
		obj.close();

	}

	public void get(String url) {
		System.out.println("Running in get()");
	}

	public void getCurrentUrl() {
		System.out.println("Running in getCurrentUrl()");

	}

	public void close() {
		System.out.println("Running in close()");

	}

}
