package TypeCasting;

public interface WebDriver {

	void get(String url);

	abstract void getCurrentUrl();

	public abstract void close();

}
