package TypeCasting;

public class A {
	
	public void show() {
		System.out.println("Running in show() of A class");
	}

	public void display() {
		System.out.println("Running in display() of A class");
	}

}
