package TypeCasting;

public class PremitiveTypeCasting {

	public static void main(String[] args) {

		int a = 30;

		double b = a; // implicit conversion

		System.out.println("value of int a = " + a);
		System.out.println("value of double b = " + b);

		System.out.println("===========================");

		char c = ' ';
		int d = c;
		double e = c;

		System.out.println("value of char c = " + c);
		System.out.println("value of int  d = " + d);
		System.out.println("value of double e = " + e);

		System.out.println("===========================");

		boolean f = true;
		// int g = f; //Type mismatch: cannot convert from boolean to int

		int h = 0;
		// boolean i = h; //Type mismatch: cannot convert from int to boolean
		
		double i = 83.888; //Type mismatch: cannot convert from double to int
		int j = (int)i; // explicit conversion
		
		System.out.println("value of double i = "+i);
		System.out.println("value of int j = "+j);
	}

}
