package TypeCasting;

// Polymorphism - Late Binding / Dynamic Polymorphism

public class B extends A {

	public static void main(String[] args) {

		// sub class Object
		B b = new B();
		b.show();
		b.display(); // Overridden method
		
		System.out.println("===============================");

		// Up casting
		A obj = new B(); // Up casting
		obj.show();
		obj.display(); 

	}

	public void display() {
		System.out.println("Running in display() of B class");
	}

}
