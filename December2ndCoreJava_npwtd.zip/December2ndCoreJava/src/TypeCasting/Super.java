package TypeCasting;

public class Super {

	public static void main(String[] args) {

		Super superObj = new Super();
		
		superObj.show();
		superObj.display();
	}
	
	public void show() {
		System.out.println("Running in show()");
	}

	public void display() {
		System.out.println("Running in display()");
	}


}
