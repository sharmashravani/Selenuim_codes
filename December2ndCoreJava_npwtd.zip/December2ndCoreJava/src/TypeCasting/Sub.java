package TypeCasting;

public class Sub extends Super {

	public static void main(String[] args) {

		// Sub Class Object
		Sub sub = new Sub();
		sub.show();
		sub.display();
		sub.demo();

		System.out.println("============ Up Casting ============");

		Super obj =  new Sub(); // Up casting // obj is the up casted object
		obj.show();
		obj.display();

		System.out.println("============ Down Casting ============");

		Sub ref = (Sub) obj; // ref is Down Casted object

		ref.demo();
		ref.show();
		ref.display();
	}

	public void demo() {
		System.out.println("Running in demo()");
	}

}
